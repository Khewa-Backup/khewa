{$cart.products_count}
