{**
 * 2007-2017 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2017 PrestaShop SA
 * @license   http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 *}
{extends file='layouts/layout-both-columns.tpl'}

{block name='header'}{/block}
{block name='left_column'}{/block}
{block name='right_column'}{/block}
{block name="layout_row_start"}{/block}
{block name="layout_row_end"}{/block}


{block name='hook_display_wrapper_top_ontainer'}{/block}
{block name='hook_display_wrapper_top'}{/block}
{block name='content_wrapper'}
    <div id="content-wrapper" class="js-content-wrapper content-only">
        {block name='content'}
            <p>Hello world! This is HTML5 Boilerplate.</p>
        {/block}
    </div>
{/block}
{block name='hook_display_wrapper_bottom_container'}{/block}
{block name='hook_display_wrapper_bottom'}{/block}

{block name='footer'}{/block}
