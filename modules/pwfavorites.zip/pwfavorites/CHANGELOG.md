CHANGELOG
=========

2.0.0
-----
* Use our new module architecture
* Use composer autoloader
* Use widgets instead of javascript for rendering the "Add to favorites" button
* Handle more resolutions in the cart slider
* (FO) Added widget to display a link to the favorites page in the header
* (FO) Use Material Icons for bxSlider arrows

1.0.2
-----
* (FO) Redirect to login page when accessing the favorites page when not logged in
* (FO) Made sure that the button is displayed when the product list is reloaded using AJAX

1.0.1
-----
* (FO) Redirect to login page when adding a product to favorites from the product page when not logged in
