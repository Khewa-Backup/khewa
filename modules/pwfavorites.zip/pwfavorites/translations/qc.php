<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pwfavorites}prestashop>pwfavorites_f6ca331a555061a26071f1da3432e4ae'] = 'Ajouter aux favoris';
$_MODULE['<{pwfavorites}prestashop>shopping_cart_footer_08233f5a18bb179416c652a1dc39164a'] = 'Produits favoris';
$_MODULE['<{pwfavorites}prestashop>customer_account_08233f5a18bb179416c652a1dc39164a'] = 'Produits favoris';
$_MODULE['<{pwfavorites}prestashop>favorites_d7778d0c64b6ba21494c97f77a66885a'] = 'Ajouter à mes favoris';
$_MODULE['<{pwfavorites}prestashop>favorites_08233f5a18bb179416c652a1dc39164a'] = 'Ajouter à mes favoris';
$_MODULE['<{pwfavorites}prestashop>settingsform_ed1aec92ec1a9c516a3e065e6e3d71e1'] = 'Couleur du bouton \"Ajouter à mes favories\" (lorsque le produit n\'a pas été ajouté aux favoris du client)';
$_MODULE['<{pwfavorites}prestashop>settingsform_0881a80a3487d3546264d4f3970814ec'] = 'Bouton \"Ajouter\"';
