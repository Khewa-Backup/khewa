<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ordersexportsalesreportpro}prestashop>exportsales_8f3f8aeac72f566f6f0fff80aa6f6d9a'] = 'Refunded Amount (Tax Excl.)';
$_MODULE['<{ordersexportsalesreportpro}prestashop>exportsales_88c4cedf6c3b0733a1cfbd07c5eba13d'] = 'Refunded Amount  (Tax Incl.)';
