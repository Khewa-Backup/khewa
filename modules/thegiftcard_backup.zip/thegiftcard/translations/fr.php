<?php
/*
* 2017 Keyrnel
*
* NOTICE OF LICENSE
*
* The source code of this module is under a commercial license.
* Each license is unique and can be installed and used on only one shop.
* Any reproduction or representation total or partial of the module, one or more of its components,
* by any means whatsoever, without express permission from us is prohibited.
* If you have not received this module from us, thank you for contacting us.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade this module to newer
* versions in the future.
*
* @author Keyrnel
* @copyright  2017 - Keyrnel SARL
* @license commercial
* International Registered Trademark & Property of Keyrnel SARL
*/

global $_MODULE;
$_MODULE = array();

$_MODULE['<{thegiftcard}prestashop>thegiftcard_e8d76b829795f3eba6d48acc0249d300'] = 'La carte cadeau';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_2a30c04c933f551d0eda20651cd4c7de'] = 'Un client en panne d\'inspiration ? Le module La Carte Cadeau donne la possibilité d\'offrir le cadeau idéal pour toutes les ocasions. Très intuitif, le module est déjà préconfiguré pour une utilisation immédiate ! Attirez de nouveaux clients et dopez votre chiffre d\'affaires en proposant des cartes cadeaux personnalisables.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_7dbd69567ef04e3920d12d80bfebc68a'] = 'Une erreur est survenue lors de l\'envoi des emails';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_75a5e204b4d8befe8d454f7c8f06bd44'] = 'Une erreur est survenue lors de la récupération des données de la carte cadeau.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_6e6bb4bddac69154313533880f0707b4'] = 'La carte cadeau n\'a pas encore eté envoyé';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_79534fa3230488a9652ae1e675bd8245'] = 'Une erreur est survenue lors de l\'indexation des devises';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_7183ce79779e629469a52d21a061cfce'] = 'Une erreur est survenue lors de la récupération des données de la règle panier.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_2182aa8ffd1097fbb25b980ebd864c3f'] = 'Une erreur est survenue lors de la récupération des données du détail de la commande.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_4dc1c8fa2f766c5e201155ee3737ed3f'] = 'Une erreur est survenue lors de la récupération des données de la commande.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_351fe57ee80fb09f58cdf5a2177bc6de'] = 'Une erreur est survenue lors de la récupération des données du client.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_4337456f10e4f7d225e78cc5b9b7c34b'] = 'Une erreur est survenue lors de l\'envoi de l\'email.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_8ca0152f06e3cdfe026cca5b3bb5ab4a'] = 'En raison des restrictions de la taille mémoire limite, cette image ne peut être chargée. Veuillez augmenter la taille mémoire limite via les options de configuration de votre serveur';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_b05c3c0bfce943b86e286e8e8103b6e5'] = 'Une erreur est survenue lors de l\'upload de l\'image.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_9ad128f3518655ed9e4e0725d849a101'] = 'Délai d\'expiration non valide.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_963ed51d7eacca62ece28bdc3f52c5fd'] = 'Montant personnalisé non valide.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_8ce5174445af4d9b1d6d0d23d11c234b'] = 'Veuillez sélectionner un montant par défaut figurant dans la liste des montants fixes';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_20c3c6b5f394a206d653ea1e9d9037c3'] = 'Les montants par défaut ne sont pas valides';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_81edf21bf2ab00c2ee1318ece13e5fc0'] = 'Le pallier entre les montants personnalisés n\'est pas valide';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_a3c085f0d457ae1104bf59365beb675a'] = 'Création du dossier "%s" impossible.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_f1c030f2fd8f1b382a4bffd04af59c2d'] = 'Le code HTML des modèles d\'emails ne peut pas contenir de code javascript.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_df644ae155e79abf54175bd15d75f363'] = 'Nom du produit';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_f15c1cae7882448b3fb0404682e17e61'] = 'Contenu';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_01c98892d178a7fcd14cb34c789f0a8a'] = 'Date d\'envoi';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_708dce7e50f23f9bcea2a45d24e22e8b'] = 'Champ personnalisable';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_278c491bdd8a53618c149c4ac790da34'] = 'Modèle';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_b2f40690858b404ed10e62bdf422c704'] = 'Montant';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_0e010c6b3fb88bf4277c880d1657787a'] = 'Groupe d\'attributs';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_b4e07e54a4f6b207a7c5dde7200f96b6'] = 'Traduction manquante';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_3cf8ff9a9faf22c8694e9d1ca70b7aa2'] = 'Impossible de charger le champ personnalisable : ';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_7610e0e9e22cc419f999691785b02725'] = 'Traduction non valide : ';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_911d2970ef810fe66e9eaf75c7b66f0e'] = 'Une erreur est survenue lors de la mise à jour du champ de traduction : ';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_89c70fb559fee9f03192d976cf35e580'] = 'Une erreur est survenue lors de la récupération des données de l\'objet : ';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_1f60cf1b981a8d4f1367dd7a5aca8359'] = 'Position de l\'image mise à jour.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_7bc85bcf163b8fa7f3e3fedb093e6708'] = 'L\'image doit être active pour la boutique "%s" pour être en couveture';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_3154baa59f6cfb5bb140601d79f61c84'] = 'Une erreur est survenue lors du déplacement de l\'image.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_1b41595b3c7a583cfbf5f7a595d1b90e'] = 'Couverture mise à jour.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_eeef315ddf1c723c49fec1b64a9c1549'] = 'La légende n\'est pas valide pour l\'image "%s".';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_b56eda7f5208052c48f2876c21729b39'] = 'Une erreur est survenue lors de la mise à jour de la légénde de l\'image "%s".';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_acec63250896891b40833012cb2b073e'] = 'Les tags ne sont pas valides pour l\'image "%s".';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_c4391f8a6b9d0c4c706bbe02eb749e13'] = 'Une erreur est survenue lors de la mise à jour des tags de l\'image "%s".';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_618c5dcb02b71849a7f2af851270b675'] = 'Une erreur est survenue lors de la mise à jour de la visibilité de la langue de l\'image "%s".';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_60841dba3263edb60544fad51cc10653'] = 'Une erreur est survenue lors de la mise à jour de la couverture.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_e9a92aa5457e4df56505ce0fb9946abf'] = 'Une erreur est survenue lors de la mise à jour des données de l\'image.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_40b773f95ef4cb6da826ac63aaa32e10'] = 'Donneées de l\'image mises à jour';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_6f5d47da950a4b4e5f17ef0457511f96'] = 'Modèle mis à jour.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_1ff79373ad24c99a3f61252d12c6d61d'] = 'Une erreur est survenue lors de la supression de l\'image.';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_44fdec47036f482b68b748f9d786801b'] = 'jours';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_628b7db04235f228d40adc671413a8c8'] = 'jour';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_da36cfaf48b9e19896e23e1207040d1e'] = 'mois';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_7436f942d5ea836cb84f1bb2527d8286'] = 'mois';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_75aeb98e5241592ad6a6c2c4c78a16ef'] = 'ans';
$_MODULE['<{thegiftcard}prestashop>thegiftcard_84cdc76cabf41bd7c961f6ab12f117d8'] = 'an';

$_MODULE['<{thegiftcard}prestashop>giftcard_8df41ed5ebc778c45f74a201e822613a'] = 'Choisissez un modèle';
$_MODULE['<{thegiftcard}prestashop>giftcard_be204b49718aa58a4164ea4acb684bdd'] = 'Choisissez le montant';
$_MODULE['<{thegiftcard}prestashop>giftcard_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Toutes';
$_MODULE['<{thegiftcard}prestashop>giftcard_0433fbe357c68c8b9a053d28917b897b'] = 'Autre montant';
$_MODULE['<{thegiftcard}prestashop>giftcard_52e85c3895f5eb06d4805e8bf01a7dff'] = 'Montant personnalisé entre';
$_MODULE['<{thegiftcard}prestashop>giftcard_be5d5d37542d75f93a87094459f76678'] = 'et';
$_MODULE['<{thegiftcard}prestashop>giftcard_10dc718bf671ff802edcc013954cd0cb'] = 'Par tranche de';
$_MODULE['<{thegiftcard}prestashop>giftcard_810339c17c5c61745a8896d48fa45bb5'] = 'Choisissez le mode d\'envoi';
$_MODULE['<{thegiftcard}prestashop>giftcard_53a10624b93334d999f75d26b45f1bb4'] = 'Imprimer à la maison';
$_MODULE['<{thegiftcard}prestashop>giftcard_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'Envoyer à un ami';
$_MODULE['<{thegiftcard}prestashop>giftcard_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_MODULE['<{thegiftcard}prestashop>giftcard_f7cc06af5b47ae5a02f14ce476a9fc25'] = 'Aucune carte cadeau pour le moment..';
$_MODULE['<{thegiftcard}prestashop>giftcard_f7531e2d0ea27233ce00b5f01c5bf335'] = 'imprimer';
$_MODULE['<{thegiftcard}prestashop>giftcard_2541d938b0a58946090d7abdde0d3890'] = 'envoyer';
$_MODULE['<{thegiftcard}prestashop>giftcard_58ddde7380dec705f4a41be178ddcaba'] = 'La carte cadeau n\'nest pas encore disponible avec cette devise';
$_MODULE['<{thegiftcard}prestashop>giftcard_865f0024b0d290e38bda156a2ab6c55e'] = 'Veuillez choisir un montant valide';

$_MODULE['<{thegiftcard}prestashop>page_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Toutes';
$_MODULE['<{thegiftcard}prestashop>page_208eb842ea4aa9e336ab96719777d608'] = 'Les cartes cadeaux ne sont pas disponibles pour le moment.';
$_MODULE['<{thegiftcard}prestashop>page_6589625e4f61320de879779e74648762'] = 'Veuillez sélectionner un mode d\'envoi';
$_MODULE['<{thegiftcard}prestashop>page_852a9150c65b95939d85f6ea21774f5c'] = 'Veuillez sélectionner un modèle et un montant';
$_MODULE['<{thegiftcard}prestashop>page_4cc2f695517d946325fea9778122d050'] = 'Veuillez sélectionner un modèle';
$_MODULE['<{thegiftcard}prestashop>page_e3799e90e30445a101f1a44fa508ee0c'] = 'Veuillez choisir un montant valide';
$_MODULE['<{thegiftcard}prestashop>page_6c5308a9786788a53f2ec483954aa105'] = 'Une erreur est survenue lors de la création de la carte cadeau avec le modèle et le montant sélectionés';
$_MODULE['<{thegiftcard}prestashop>page_90c61c948d0a86c9c806ae68080a7502'] = 'Une erreur est survenue lors de la récupération des données de la déclinaison choisie';
$_MODULE['<{thegiftcard}prestashop>page_c96280f76032df218d08eebbb62f8696'] = 'Veuillez sélectionner une date d\'envoi valide';
$_MODULE['<{thegiftcard}prestashop>page_2dcefdd30cb02c83432afea2cd6700bf'] = 'Veuillez saisir un email valide';
$_MODULE['<{thegiftcard}prestashop>page_bd3fbf2643b8ce25affbadf196a43140'] = 'Une erreur est survenue lors de l\'enregistrement des données';
$_MODULE['<{thegiftcard}prestashop>page_634d80b6b0720feb33da6b29cca18cbd'] = 'Veuillez remplir tous les champs';
$_MODULE['<{thegiftcard}prestashop>page_0b9a4acd6cf8c008fb1116c146757215'] = 'Une erreur est survenue lors de la récupération des données des champs personnalisables';

$_MODULE['<{thegiftcard}prestashop>generator_e8af6452509c50583011129b68888fa8'] = 'La période par défaut est d\'un an.';
$_MODULE['<{thegiftcard}prestashop>generator_519cb17437f0dfdc80c55a4f766412a1'] = 'Délai de validité';
$_MODULE['<{thegiftcard}prestashop>generator_03727ac48595a24daed975559c944a44'] = 'Jour';
$_MODULE['<{thegiftcard}prestashop>generator_7cbb885aa1164b390a0bc050a64e1812'] = 'Mois';
$_MODULE['<{thegiftcard}prestashop>generator_537c66b24ef5c83b7382cdc3f34885f2'] = 'Année';
$_MODULE['<{thegiftcard}prestashop>generator_7df96b18c230f90ada0a9e2307226338'] = 'Modèles';
$_MODULE['<{thegiftcard}prestashop>generator_1306bade25c9c93111838baadc58300e'] = 'Carte cadeau';
$_MODULE['<{thegiftcard}prestashop>generator_be53a0541a6d36f6ecb879fa2c584b08'] = 'Image';
$_MODULE['<{thegiftcard}prestashop>generator_272ba7d164aa836995be6319a698be84'] = 'Légende';
$_MODULE['<{thegiftcard}prestashop>generator_189f63f277cd73395561651753563065'] = 'Tags';
$_MODULE['<{thegiftcard}prestashop>generator_56ad2dda6529d24106974574617e3bbb'] = 'Visibilité langue';
$_MODULE['<{thegiftcard}prestashop>generator_abdffc07f137a3b4b3e4df13d2cafee4'] = 'Toutes les langues';
$_MODULE['<{thegiftcard}prestashop>generator_06933067aafd48425d67bcb01bba5cb6'] = 'Mettre à jour';
$_MODULE['<{thegiftcard}prestashop>generator_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Position';
$_MODULE['<{thegiftcard}prestashop>generator_c795dfff10a7c952f4c5438951e9ece9'] = 'Couverture';
$_MODULE['<{thegiftcard}prestashop>generator_7be66046997731ac05844f11ee4f6a76'] = 'Supprimer cette image';
$_MODULE['<{thegiftcard}prestashop>generator_ec211f7c20af43e742bf2570c3cb84f9'] = 'Ajouter';
$_MODULE['<{thegiftcard}prestashop>generator_ea4788705e6873b424c65e91c2846b19'] = 'Annuler';
$_MODULE['<{thegiftcard}prestashop>generator_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{thegiftcard}prestashop>generator_73803d19273b86e91f83d39147a62d01'] = 'Définissez les montants disponibles pour la carte cadeau';
$_MODULE['<{thegiftcard}prestashop>generator_d3968fe61a2b33f02e9cd8606b029a57'] = 'Montants';
$_MODULE['<{thegiftcard}prestashop>generator_dec7c7834c344a9bf5a36fc2e76edfbd'] = 'Vous devez saisir les limites du montant personnalisé puis sélectionner les montants fixes qui seront directement visibles par vos clients.';
$_MODULE['<{thegiftcard}prestashop>generator_96dc7a93efff58b2157f99a4682aba1c'] = 'Définissez les limites du montant personnalisé';
$_MODULE['<{thegiftcard}prestashop>generator_81dcfc7724f3c0d1473c96157f6abc1e'] = 'Montant personnalisé';
$_MODULE['<{thegiftcard}prestashop>generator_d98a07f84921b24ee30f86fd8cd85c3c'] = 'de';
$_MODULE['<{thegiftcard}prestashop>generator_01b6e20344b68835c5ed1ddedf20d531'] = 'à';
$_MODULE['<{thegiftcard}prestashop>generator_cc171d5ca84dddbed4e5e1d81fede874'] = 'Définissez la fourchette de prix entre chaque montant personnalisé. Une valeur basse augmente la durée du processus de génération des cadeaux cadeaux';
$_MODULE['<{thegiftcard}prestashop>generator_e7c5c1b848afcd8b15f11df468ca408b'] = 'Fourchette entre chaque montant personnalisé';
$_MODULE['<{thegiftcard}prestashop>generator_73943e4f5d8c72f39d7aea0d0cb250f8'] = 'Chaque montant doit être suivi par une virgule.';
$_MODULE['<{thegiftcard}prestashop>generator_03b5abfce94180e5b0ba10b2a4f89b43'] = 'Montant fixe';
$_MODULE['<{thegiftcard}prestashop>generator_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{thegiftcard}prestashop>generator_7389134008adf19844ffebe3003cf819'] = 'Saisissez le montant par défaut qui sera affiché en front-office';
$_MODULE['<{thegiftcard}prestashop>generator_34484cda54c18edef6f67a5d584381f1'] = 'Sélectionnez la devise à modifier';
$_MODULE['<{thegiftcard}prestashop>generator_386c339d37e737a436499d423a77df0c'] = 'Devise';
$_MODULE['<{thegiftcard}prestashop>generator_0133f393f246b25a69f56e6af54bdf53'] = 'Activez pour afficher la carte cadeau sur cette devise en front-office';
$_MODULE['<{thegiftcard}prestashop>generator_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Active';
$_MODULE['<{thegiftcard}prestashop>generator_6ec8432916067460a473509b7f5f553f'] = 'Montant par défaut';
$_MODULE['<{thegiftcard}prestashop>generator_d109e78f4f1900f374695aafe75fbdd0'] = 'Activez pour supprimer automatiquement les déclinaisons non utilisées (réduit le temps de chargement du module)';
$_MODULE['<{thegiftcard}prestashop>generator_b65885fc37ea02bb908df26b4ef9a76e'] = 'Supprimer automatiquement les déclinaisons inutiles';
$_MODULE['<{thegiftcard}prestashop>generator_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{thegiftcard}prestashop>generator_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{thegiftcard}prestashop>generator_3793053472468f0234c34d90ad7ecf79'] = 'Activez pour cumuluer ou non les cartes cadeaux avec les autres règles paniers';
$_MODULE['<{thegiftcard}prestashop>generator_079abe9e0abe585475885949c286ade5'] = 'Utiliser la fonctionnalité de compatibilité des règles paniers';
$_MODULE['<{thegiftcard}prestashop>generator_c75f214220bc3c7b561eb47cb88f5f0e'] = 'Cumulabilité avec les autres règles paniers';
$_MODULE['<{thegiftcard}prestashop>generator_48a3f0712fab5254bd3102b9dad94794'] = 'Sélectionnez la taxe à appliquer sur la carte cadeau';
$_MODULE['<{thegiftcard}prestashop>generator_4b78ac8eb158840e9638a3aeb26c4a9d'] = 'Taxe';
$_MODULE['<{thegiftcard}prestashop>generator_b2f40690858b404ed10e62bdf422c704'] = 'Montant';
$_MODULE['<{thegiftcard}prestashop>generator_fb82b803ac6f7e4a2ce02f7c75b21a5c'] = 'Appliquer automatiquement ce montant lors de la sélection de l\'image';

$_MODULE['<{thegiftcard}prestashop>display_9dc0b7bdd32d5e30f4d71eb5abb6b8d4'] = 'Paramètres d\'affichage';
$_MODULE['<{thegiftcard}prestashop>display_9daf6056aa0d34486551a12e1d6b9163'] = 'Paramètres de la catégorie';
$_MODULE['<{thegiftcard}prestashop>display_6252c0f2c2ed83b7b06dfca86d4650bb'] = 'Caractères non valides:';
$_MODULE['<{thegiftcard}prestashop>display_bb34a159a88035cce7ef1607e7907f8f'] = 'Nom de la catégorie';
$_MODULE['<{thegiftcard}prestashop>display_9b3d7ea6e0cf99ae03d7e80054bf65c9'] = 'Description de la catégorie';
$_MODULE['<{thegiftcard}prestashop>display_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{thegiftcard}prestashop>display_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_MODULE['<{thegiftcard}prestashop>display_fd83313d56cbf155bc50238ba2239cd3'] = 'Uploader une image de bannière depuis votre ordinateur';
$_MODULE['<{thegiftcard}prestashop>display_92d7981ef356bbf4654db23d375ad89f'] = 'Image de la catégorie';
$_MODULE['<{thegiftcard}prestashop>display_7bab53b1b344e8938987bff4a5a0637c'] = 'Activez pour afficher un lien vers la page carte cadeau dans le menu';
$_MODULE['<{thegiftcard}prestashop>display_15b91ddc83ba9762eb85a8ec42574791'] = 'Afficher dans le menu';
$_MODULE['<{thegiftcard}prestashop>display_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{thegiftcard}prestashop>display_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{thegiftcard}prestashop>display_1b9f6d26d11d734ef3e8905a64d5713b'] = 'Activez pour afficher la catégorie carte cadeau. Utilise si vous souhaitez indexer la carte cadeau dans la recherche';
$_MODULE['<{thegiftcard}prestashop>display_b7d750231f88b3e24165c394b61971b7'] = 'Afficher la catégorie';
$_MODULE['<{thegiftcard}prestashop>display_7beed9c0f20b4800c4db00debf101206'] = 'Association aux catégories';
$_MODULE['<{thegiftcard}prestashop>display_fb4efa2dbc3ca54c8de6006d110f80c5'] = 'Visibilité de la carte cadeau';
$_MODULE['<{thegiftcard}prestashop>display_13787cfb1a15ae6690a29d3895c54de9'] = 'Partout';
$_MODULE['<{thegiftcard}prestashop>display_96c7d7f87187cc14ead1f887407d0edc'] = 'Catalogue uniquement';
$_MODULE['<{thegiftcard}prestashop>display_2ba18b8df558ceaabcc89f3a16772a9b'] = 'Recherche uniquement';
$_MODULE['<{thegiftcard}prestashop>display_e56fc964976b3770a35b2d6fb4b78224'] = 'Nulle part';
$_MODULE['<{thegiftcard}prestashop>display_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{thegiftcard}prestashop>display_6cca136d1846ffcd272db5faf7d5281f'] = 'Paramètres du produit';
$_MODULE['<{thegiftcard}prestashop>display_df644ae155e79abf54175bd15d75f363'] = 'Nom du produit';
$_MODULE['<{thegiftcard}prestashop>display_c1069a480848e06782b81b8bea9c0c94'] = 'Récapitulatif';

$_MODULE['<{thegiftcard}prestashop>emails_e29252902fd4eaee6279ea5b60bc9092'] = 'Modèles d\'email';
$_MODULE['<{thegiftcard}prestashop>emails_f4ada54ade1010a922a6a009775785c5'] = 'Veuillez activer le module cronjobs pour permettre à vos clients de saisir une date d\'envoi différée des cartes cadeaux.';
$_MODULE['<{thegiftcard}prestashop>emails_1fb0dca951abc12549f7b257b4b7c1df'] = 'Modèle \'Imprimer à la maison\'';
$_MODULE['<{thegiftcard}prestashop>emails_6c0745a55a41e0937be6f2e8cd6edde1'] = 'Modèle \'Envoyer à un ami\'';
$_MODULE['<{thegiftcard}prestashop>emails_27399a93bfde8d654c38ebe4687d996c'] = 'Taille de l\'image de la carte cadeau';
$_MODULE['<{thegiftcard}prestashop>emails_c7892ebbb139886662c6f2fc8c450710'] = 'Sujet';
$_MODULE['<{thegiftcard}prestashop>emails_d7b54d98a923f3db1e1d6f4c174f8286'] = 'Balise "title"';
$_MODULE['<{thegiftcard}prestashop>emails_f15c1cae7882448b3fb0404682e17e61'] = 'Contenu';
$_MODULE['<{thegiftcard}prestashop>emails_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';

$_MODULE['<{thegiftcard}prestashop>configuration_c33e404a441c6ba9648f88af3c68a1ca'] = 'Statistiques';
$_MODULE['<{thegiftcard}prestashop>configuration_c286cfd1bc92a5ce56ba5438837bafa0'] = 'Générateur de carte cadeaux';
$_MODULE['<{thegiftcard}prestashop>configuration_e29252902fd4eaee6279ea5b60bc9092'] = 'Modèles d\'email';
$_MODULE['<{thegiftcard}prestashop>configuration_9dc0b7bdd32d5e30f4d71eb5abb6b8d4'] = 'Paramètre d\'affichage';
$_MODULE['<{thegiftcard}prestashop>configuration_0b8d92bc19b720bb1065649535463409'] = 'Traductions';

$_MODULE['<{thegiftcard}prestashop>stats_c33e404a441c6ba9648f88af3c68a1ca'] = 'Statistiques';
$_MODULE['<{thegiftcard}prestashop>stats_a13ca885ca869f5454febb1d70f69bf5'] = 'devises doivent être indexées';
$_MODULE['<{thegiftcard}prestashop>stats_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{thegiftcard}prestashop>stats_278c491bdd8a53618c149c4ac790da34'] = 'Modèle';
$_MODULE['<{thegiftcard}prestashop>stats_b2f40690858b404ed10e62bdf422c704'] = 'Montant';
$_MODULE['<{thegiftcard}prestashop>stats_a240fa27925a635b08dc28c9e4f9216d'] = 'Commande';
$_MODULE['<{thegiftcard}prestashop>stats_0862f5d4211bdb50102141618d57e2a1'] = 'Code de réduction';
$_MODULE['<{thegiftcard}prestashop>stats_73ee0828f318c935144b829c08a21c84'] = 'Date d\'achat';
$_MODULE['<{thegiftcard}prestashop>stats_019d1ca7d50cc54b995f60d456435e87'] = 'Utilisée';
$_MODULE['<{thegiftcard}prestashop>stats_82948756e60e1a7da931989c9bc617d8'] = 'Date d\'utilisation';
$_MODULE['<{thegiftcard}prestashop>stats_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Active';
$_MODULE['<{thegiftcard}prestashop>stats_d30fd576bd308f6facc9343ebd031b8e'] = 'Expiration';
$_MODULE['<{thegiftcard}prestashop>stats_cfa4593b1fb6aea2e32d9928f2c4349b'] = 'Email envoyé';
$_MODULE['<{thegiftcard}prestashop>stats_fe77adfb2bb74b69920ef026cc5a55b7'] = 'carte cadeau';
$_MODULE['<{thegiftcard}prestashop>stats_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{thegiftcard}prestashop>stats_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{thegiftcard}prestashop>stats_087fb8756d4add87f2d162304ccd486b'] = 'Aucun enregistrement trouvé';
$_MODULE['<{thegiftcard}prestashop>stats_c4cd4c4cbdcfd0561977195cc53a4482'] = 'Des emails n\'ont pas été correctement envoyés aux utilisateurs. Utiliser le bouton suivant pour les envoyer manuellement.';

$_MODULE['<{thegiftcard}prestashop>translations_0b8d92bc19b720bb1065649535463409'] = 'Traductions';
$_MODULE['<{thegiftcard}prestashop>translations_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';

return $_MODULE;
