<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pronesissizechart}prestashop>product_page17_c5c24b06d40b5ca07c991a417b6dd1bf'] = 'Voir la charte des grandeurs';
